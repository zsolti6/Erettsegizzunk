-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: erettsegizzunk2.mysql.database.azure.com    Database: erettsegizzunk
-- ------------------------------------------------------
-- Server version	8.0.40-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `theme`
--

DROP TABLE IF EXISTS `theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theme` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_hungarian_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme`
--

LOCK TABLES `theme` WRITE;
/*!40000 ALTER TABLE `theme` DISABLE KEYS */;
INSERT INTO `theme` (`id`, `name`) VALUES (1, 'Szövegértés'),(2, 'Szövegalkotás'),(3, 'Irodalomtörténet'),(4, 'Műelemzés és versértelmezés'),(5, 'Irodalmi műfajok és műnemek'),(6, 'Intertextualitás és motívumok'),(7, 'Kortárs irodalom és világirodalom'),(8, 'Műfajismeret'),(9, 'A kereszténység'),(10, 'Az iszlám vallás'),(11, 'Újkor (1492–1789)'),(12, 'Az 1848–49-es forradalom és szabadságharc'),(13, 'Az alkotmányos monarchia kialakulása Angliában'),(14, 'Újkor (1789–1914)'),(15, 'A polgári állam és a jogállamiság kialakulása'),(16, 'A második világháború és a holokauszt'),(17, 'A Horthy-korszak és a két világháború közötti Magyarország (1920–1944)'),(18, '20. század (1914–1945)'),(19, 'A hidegháború (1947–1991)'),(20, 'Algebra'),(21, 'Abszolútérték, gyök'),(22, 'Bizonyítások'),(23, 'Egyenletek'),(24, 'Halmazok'),(25, 'Kombinatorika'),(26, 'Síkgeometria'),(27, 'Sorozatok');
/*!40000 ALTER TABLE `theme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-28  7:36:22
