-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: erettsegizzunk2.mysql.database.azure.com    Database: erettsegizzunk
-- ------------------------------------------------------
-- Server version	8.0.40-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `task_theme`
--

DROP TABLE IF EXISTS `task_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_theme` (
  `taskId` int NOT NULL AUTO_INCREMENT,
  `themeId` int NOT NULL,
  PRIMARY KEY (`taskId`,`themeId`),
  KEY `themeId` (`themeId`),
  CONSTRAINT `task_theme_ibfk_1` FOREIGN KEY (`taskId`) REFERENCES `task` (`id`),
  CONSTRAINT `task_theme_ibfk_2` FOREIGN KEY (`themeId`) REFERENCES `theme` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_theme`
--

LOCK TABLES `task_theme` WRITE;
/*!40000 ALTER TABLE `task_theme` DISABLE KEYS */;
INSERT INTO task_theme (taskId, themeId) VALUES (1, 1),(1, 2),(1, 3),(2, 3),(3, 3),(4, 3),(5, 3),(6, 3),(7, 3),(8, 3),(9, 3),(10, 3),(11, 3),(12, 3),(13, 3),(14, 3),(15, 3),(16, 3),(17, 3),(1, 4),(1, 5),(1, 6),(1, 7),(1, 8),(2, 8),(3, 8),(4, 8),(5, 8),(6, 8),(7, 8),(8, 8),(9, 8),(10, 8),(11, 8),(12, 8),(13, 8),(14, 8),(15, 8),(16, 8),(17, 8),(1, 9),(62, 9),(63, 9),(1, 10),(64, 10),(65, 10),(66, 10),(67, 10),(1, 11),(68, 11),(69, 12),(70, 12),(71, 12),(72, 12),(69, 13),(70, 13),(71, 13),(72, 13),(73, 14),(73, 15),(77, 16),(74, 17),(75, 17),(76, 17),(74, 18),(75, 18),(76, 18),(77, 18),(78, 18),(78, 19),(30, 20),(31, 20),(31, 21),(32, 21),(36, 21),(41, 21),(46, 21),(51, 21),(52, 21),(26, 22),(29, 22),(35, 22),(44, 22),(49, 22),(50, 22),(54, 22),(30, 23),(31, 23),(18, 24),(19, 24),(25, 24),(28, 24),(33, 24),(43, 24),(48, 24),(55, 24),(56, 24),(57, 24),(20, 25),(22, 25),(24, 25),(30, 25),(34, 25),(40, 25),(45, 25),(53, 25),(58, 25),(60, 25),(23, 26),(38, 26),(39, 26),(61, 26),(21, 27),(27, 27),(37, 27),(42, 27),(47, 27),(59, 27);
/*!40000 ALTER TABLE `task_theme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-10  7:36:18
